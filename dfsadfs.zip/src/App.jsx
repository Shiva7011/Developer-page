import "./assets/css/index.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home/Home";
import ShubhamHero from "./pages/ShubhamHero/ShubhamHero";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Shubhamhero" element={<ShubhamHero />} />
      </Routes>
    </BrowserRouter>
  );
}


