// 1️⃣ IMPORTS – sabse upar
import Meteors from "@/components/ui/meteors";
import GridBox from "@/components/GridBox";
import HeroButton from "@/components/HeroButton";
import shubhamImg from "@/assets/images/shubham.jpeg";
import shivaImg from "@/assets/images/shivaimage.jpeg";
import bhulvaImg from "@/assets/images/bhulva.png";
import gaganImg from "@/assets/images/gagan.png";
import { useNavigate } from "react-router-dom";
import "@/assets/css/home-text.css";


// 2️⃣ YAHAN GridBackground likho (function se pehle)
const GridBackground = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-20">
      <div className="absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,transparent_0%,black)]">
        <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%">
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <rect
              width="40"
              height="40"
              fill="none"
              stroke="white"
              strokeWidth="0.5"
              className="opacity-40"
            />
          </pattern>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>
    </div>
  );
};


// 3️⃣ AB Home component
export default function Home() {
      const navigate = useNavigate();
  return (
    <main className="relative min-h-screen bg-[#020617] overflow-hidden">

      {/* BACKGROUND */}
      <GridBackground />
      <div className="absolute inset-0 pointer-events-none">
        <Meteors number={10} />
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center">

  {/* INNER WRAPPER */}
 <div className="w-full max-w-[1400px] px-6 sm:px-12 lg:px-20 flex flex-col">


    <h2 className="pt-[20px] text-3xl sm:text-4xl font-semibold text-white mb-4">
  Meet the {" "}
  <span className="gradient-text">
    Developer
  </span>
</h2>


    {/* PARAGRAPH */}
    <p className="home-description  mb-16">
      This project has been developed by our team of four developers,
       with each member contributing to the design, development, and implementation of the system.
        Through effective collaboration and division of responsibilities, we ensured that the final solution is robust,
         efficient, and well structured.
    </p>

    {/* GRID */}
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-10 place-items-center">

<GridBox title="Project Lead" image={shubhamImg} name="Shubham Nishad">
  <HeroButton
    size="sm"
    label="Know More"
    onClick={() => navigate("/Shubhamhero")}   // 👈 YAHI REDIRECT
  />
</GridBox>


<GridBox title="Team Member" image={shivaImg} name="Shiva Singh">
  <HeroButton
    label="Know More"
    onClick={() => console.log("Skills clicked")}
  />
</GridBox>

<GridBox title="Team Member" image={bhulvaImg} name="Bhulva">
  <HeroButton
    label="Know More"
    onClick={() => console.log("Projects clicked")}
  />
</GridBox>

<GridBox title="Team Member" image={gaganImg} name="Gagan Kumar">
  <HeroButton
    label="Know More"
    onClick={() => console.log("Contact clicked")}
  />
</GridBox>
    </div> {/* grid */}
    <br></br>
    {/* 👇 PARAGRAPH BELOW GRID */}
<p className="home-description home-description-bottom">
  Through effective teamwork and clear division of responsibilities, the
  development team focused on building a high-quality application that meets
  technical standards and user requirements. The combined efforts of the
  developers demonstrate professionalism, technical competence, and a
  commitment to excellence.
</p>
<br></br>
<br></br>
  </div>   {/* inner wrapper */}
</div>     {/* content */}

    </main>
  );
}
